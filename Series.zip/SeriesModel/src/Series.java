import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class Series {

    public Series(int par, String breaking_Bad, int par1) {
    }
    private List<SeriesModel> seriesList = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);

    public void displayMenu() {
        System.out.println("LATEST SERIES - 2025");
        System.out.println("************************");
        System.out.println("Please select one of the following menu items:");
        System.out.println("(1) Capture a new series.");
        System.out.println("(2) Search for a series.");
        System.out.println("(3) Update series age restriction.");
        System.out.println("(4) Delete a series.");
        System.out.println("(5) Print series report - 2025");
        System.out.println("(6) Exit Application.");
        System.out.print("Enter (1) to launch menu or any other key to exit: ");
    }

    public void launchMenu() {
        int choice;
        do {
            displayMenu();
            try {
                choice = scanner.nextInt();
                scanner.nextLine(); // consume newline
                switch (choice) {
                    case 1:
                        captureSeries();
                        break;
                    case 2:
                        searchSeries();
                        break;
                    case 3:
                        updateSeries();
                        break;
                    case 4:
                        deleteSeries();
                        break;
                    case 5:
                        seriesReport();
                        break;
                    case 6:
                        exitSeriesApplication();
                        return;
                    default:
                        System.out.println("Invalid option. Please try again.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine(); // consume invalid input
                choice = 0; // to keep the loop running
            }
        } while (choice != 6);
    }

    public void captureSeries() {
        System.out.println("CAPTURE A NEW SERIES");
        System.out.println("*********************");
        System.out.print("Enter the series id: ");
        String id = scanner.nextLine();
        System.out.print("Enter the series name: ");
        String name = scanner.nextLine();
        int ageRestriction = getValidAgeRestriction();
        int numberOfEpisodes = getValidNumberOfEpisodes();

        SeriesModel newSeries = new SeriesModel(id, name, ageRestriction, numberOfEpisodes);
        seriesList.add(newSeries);
        System.out.println("Series processed successfully!!!");
    }

    private int getValidAgeRestriction() {
        int age;
        while (true) {
            System.out.print("Enter the series age restriction (2-18): ");
            try {
                String input = scanner.nextLine();
                age = Integer.parseInt(input);
                if (age >= 2 && age <= 18) {
                    return age;
                } else {
                    System.out.println("You have entered an incorrect series age!!!");
                    System.out.println("Please re-enter the series age >>");
                }
            } catch (NumberFormatException e) {
                System.out.println("You have entered an invalid non-number age restriction!!!");
                System.out.println("Please re-enter the series age >>");
            }
        }
    }

    private int getValidNumberOfEpisodes() {
        int episodes;
        while (true) {
            System.out.print("Enter the number of episodes: ");
            try {
                String input = scanner.nextLine();
                episodes = Integer.parseInt(input);
                return episodes;
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number for episodes.");
            }
        }
    }

    public void searchSeries() {
        System.out.println("SEARCH A SERIES");
        System.out.println("****************");
        System.out.print("Enter the series id to search: ");
        String searchId = scanner.nextLine();
        SeriesModel foundSeries = findSeriesById(searchId);

        if (foundSeries != null) {
            System.out.println("SERIES ID: " + foundSeries.getSeriesId());
            System.out.println("SERIES NAME: " + foundSeries.getSeriesName());
            System.out.println("SERIES AGE RESTRICTION: " + foundSeries.getSeriesAgeRestriction());
            System.out.println("SERIES NUMBER OF EPISODES: " + foundSeries.getSeriesNumberOfEpisodes());
        } else {
            System.out.println("Series with Series Id: " + searchId + " was not found!");
        }
    }

    public void updateSeries() {
        System.out.println("UPDATE SERIES");
        System.out.println("*************");
        System.out.print("Enter the series id to update: ");
        String updateId = scanner.nextLine();
        SeriesModel seriesToUpdate = findSeriesById(updateId);

        if (seriesToUpdate != null) {
            System.out.println("Enter the new series name: ");
            String newName = scanner.nextLine();
            int newAgeRestriction = getValidAgeRestriction();
            int newNumberOfEpisodes = getValidNumberOfEpisodes();
            
            seriesToUpdate.setSeriesName(newName);
            seriesToUpdate.setSeriesAgeRestriction(newAgeRestriction);
            seriesToUpdate.setSeriesNumberOfEpisodes(newNumberOfEpisodes);
            
            System.out.println("Series updated successfully.");
        } else {
            System.out.println("Series with Series Id: " + updateId + " was not found!");
        }
    }

    public void deleteSeries() {
        System.out.println("DELETE SERIES");
        System.out.println("*************");
        System.out.print("Enter the series id to delete: ");
        String deleteId = scanner.nextLine();
        SeriesModel seriesToDelete = findSeriesById(deleteId);

        if (seriesToDelete != null) {
            System.out.print("Are you sure you want to delete series " + deleteId + " from the system? Yes (y) to delete: ");
            String confirmation = scanner.nextLine();
            if (confirmation.equalsIgnoreCase("y")) {
                seriesList.remove(seriesToDelete);
                System.out.println("Series with Series Id: " + deleteId + " WAS deleted!");
            } else {
                System.out.println("Deletion cancelled.");
            }
        } else {
            System.out.println("Series with Series Id: " + deleteId + " was not found!");
        }
    }

    public void seriesReport() {
        System.out.println("SERIES REPORT");
        System.out.println("**************");
        if (seriesList.isEmpty()) {
            System.out.println("No series data available.");
            return;
        }

        for (int i = 0; i < seriesList.size(); i++) {
            SeriesModel series = seriesList.get(i);
            System.out.println("Series " + (i + 1));
            System.out.println("-------------------------------------");
            System.out.println("SERIES ID: " + series.getSeriesId());
            System.out.println("SERIES NAME: " + series.getSeriesName());
            System.out.println("SERIES AGE RESTRICTION: " + series.getSeriesAgeRestriction());
            System.out.println("SERIES NUMBER OF EPISODES: " + series.getSeriesNumberOfEpisodes());
            System.out.println();
        }
    }

    public void exitSeriesApplication() {
        System.out.println("Exiting application...");
        scanner.close();
    }

    private SeriesModel findSeriesById(String id) {
        for (SeriesModel series : seriesList) {
            if (series.getSeriesId().equals(id)) {
                return series;
            }
        }
        return null;
    }
}
//Reference List
//OpenAI (2025) ChatGPT [AI chatbot]. Available at: https://chat.openai.com/ (Accessed: 04 September 2025).
//Google (2025) Gemini [AI chatbot]. Available at: https://gemini.google.com/ (Accessed: 04 September 2025). 