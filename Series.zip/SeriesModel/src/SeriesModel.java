 import java.io.Serializable;

public class SeriesModel implements Serializable {
    private String seriesId;
    private String seriesName;
    private int seriesAgeRestriction;
    private int seriesNumberOfEpisodes;

    public SeriesModel(String seriesId, String seriesName, int seriesAgeRestriction, int seriesNumberOfEpisodes) {
        this.seriesId = seriesId;
        this.seriesName = seriesName;
        this.seriesAgeRestriction = seriesAgeRestriction;
        this.seriesNumberOfEpisodes = seriesNumberOfEpisodes;
    }

    // Getters and Setters for all fields
    public String getSeriesId() {
        return seriesId;
    }

    public void setSeriesId(String seriesId) {
        this.seriesId = seriesId;
    }

    public String getSeriesName() {
        return seriesName;
    }

    public void setSeriesName(String seriesName) {
        this.seriesName = seriesName;
    }

    public int getSeriesAgeRestriction() {
        return seriesAgeRestriction;
    }

    public void setSeriesAgeRestriction(int seriesAgeRestriction) {
        this.seriesAgeRestriction = seriesAgeRestriction;
    }

    public int getSeriesNumberOfEpisodes() {
        return seriesNumberOfEpisodes;
    }

    public void setSeriesNumberOfEpisodes(int seriesNumberOfEpisodes) {
        this.seriesNumberOfEpisodes = seriesNumberOfEpisodes;
    }
} 
//Reference List
//OpenAI (2025) ChatGPT [AI chatbot]. Available at: https://chat.openai.com/ (Accessed: 04 September 2025).
//Google (2025) Gemini [AI chatbot]. Available at: https://gemini.google.com/ (Accessed: 04 September 2025). 