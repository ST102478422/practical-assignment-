public class Main {
    public static void main(String[] args) {
        Series seriesApp = new Series(1, "Breaking Bad", 18);
        seriesApp.launchMenu();
    }
}
//Reference List
//OpenAI (2025) ChatGPT [AI chatbot]. Available at: https://chat.openai.com/ (Accessed: 04 September 2025).
//Google (2025) Gemini [AI chatbot]. Available at: https://gemini.google.com/ (Accessed: 04 September 2025). 