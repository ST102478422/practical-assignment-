import org.junit.Test;
import static org.junit.jupiter.api.Assertions.*;

class SeriesModelTest {

    @Test
    void testSeriesModel() {
        // Test data
        String seriesId = "101";
        String seriesName = "Extreme Sports";
        int ageRestriction = 12;
        int numberOfEpisodes = 10;

        // 1. Test the constructor
        SeriesModel series = new SeriesModel(seriesId, seriesName, ageRestriction, numberOfEpisodes);

        // 2. Test the getters to ensure the constructor worked correctly
        assertEquals(seriesId, series.getSeriesId());
        assertEquals(seriesName, series.getSeriesName());
        assertEquals(ageRestriction, series.getSeriesAgeRestriction());
        assertEquals(numberOfEpisodes, series.getSeriesNumberOfEpisodes());

        // 3. Test the setters
        String newSeriesId = "102";
        String newSeriesName = "Bargain Hunters";
        int newAgeRestriction = 10;
        int newNumberOfEpisodes = 10;

        series.setSeriesId(newSeriesId);
        series.setSeriesName(newSeriesName);
        series.setSeriesAgeRestriction(newAgeRestriction);
        series.setSeriesNumberOfEpisodes(newNumberOfEpisodes);

        // 4. Test the getters again to confirm setters worked
        assertEquals(newSeriesId, series.getSeriesId());
        assertEquals(newSeriesName, series.getSeriesName());
        assertEquals(newAgeRestriction, series.getSeriesAgeRestriction());
        assertEquals(newNumberOfEpisodes, series.getSeriesNumberOfEpisodes());
    }
}
//Reference List
//OpenAI (2025) ChatGPT [AI chatbot]. Available at: https://chat.openai.com/ (Accessed: 04 September 2025).
//Google (2025) Gemini [AI chatbot]. Available at: https://gemini.google.com/ (Accessed: 04 September 2025). 