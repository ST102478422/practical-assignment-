public class MainApp {
    public static void main(String[] args) {
        TVSeriesManagement manager = new TVSeriesManagement();

        // Add series
        manager.addSeries(new Series(1, "Breaking Bad", 18));
        manager.addSeries(new Series(2, "Stranger Things", 16));
        manager.addSeries(new AnimatedSeries(3, "Naruto", 13, "Pierrot"));

        // Display report
        manager.displayReport();

        // Update series
        manager.updateSeries(1, "Better Call Saul", 18);

        // Delete series
        manager.deleteSeries(2);

        // Final report
        System.out.println("\nAfter Updates:");
        manager.displayReport();
    }
}
//Reference List
//OpenAI (2025) ChatGPT [AI chatbot]. Available at: https://chat.openai.com/ (Accessed: 04 September 2025).
//Google (2025) Gemini [AI chatbot]. Available at: https://gemini.google.com/ (Accessed: 04 September 2025). 
