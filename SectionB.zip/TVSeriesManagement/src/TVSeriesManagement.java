// Parent class
class Series {
    private int id;
    private String title;
    private int ageRestriction;

    public Series(int id, String title, int ageRestriction) {
        this.id = id;
        this.title = title;
        this.ageRestriction = ageRestriction;
    }

    // Getters & Setters
    public int getId() { return id; }
    public String getTitle() { return title; }
    public int getAgeRestriction() { return ageRestriction; }

    public void setTitle(String title) { this.title = title; }
    public void setAgeRestriction(int ageRestriction) { this.ageRestriction = ageRestriction; }

    @Override
    public String toString() {
        return id + " - " + title + " (Age " + ageRestriction + "+)";
    }
}

// Child class (inheritance)
class AnimatedSeries extends Series {
    private String animationStudio;

    public AnimatedSeries(int id, String title, int ageRestriction, String studio) {
        super(id, title, ageRestriction);
        this.animationStudio = studio;
    }

    @Override
    public String toString() {
        return super.toString() + " | Animation Studio: " + animationStudio;
    }
}

//Reference List
//OpenAI (2025) ChatGPT [AI chatbot]. Available at: https://chat.openai.com/ (Accessed: 04 September 2025).
//Google (2025) Gemini [AI chatbot]. Available at: https://gemini.google.com/ (Accessed: 04 September 2025).  

