import java.util.ArrayList;

class TVSeriesManagement {
    private ArrayList<Series> seriesList = new ArrayList<>();

    public void addSeries(Series s) {
        seriesList.add(s);
    }

    public Series searchSeries(int id) {
        for (Series s : seriesList) {
            if (s.getId() == id) return s;
        }
        return null;
    }

    public boolean updateSeries(int id, String newTitle, int newAge) {
        Series s = searchSeries(id);
        if (s != null) {
            s.setTitle(newTitle);
            s.setAgeRestriction(newAge);
            return true;
        }
        return false;
    }

    public boolean deleteSeries(int id) {
        Series s = searchSeries(id);
        if (s != null) {
            seriesList.remove(s);
            return true;
        }
        return false;
    }

    public boolean isValidAgeRestriction(int age) {
        return age >= 7 && age <= 21;
    }

    public void displayReport() {
        System.out.println("==== TV SERIES REPORT ====");
        for (Series s : seriesList) {
            System.out.println(s);
        }
    }
}
//Reference List
//OpenAI (2025) ChatGPT [AI chatbot]. Available at: https://chat.openai.com/ (Accessed: 04 September 2025).
//Google (2025) Gemini [AI chatbot]. Available at: https://gemini.google.com/ (Accessed: 04 September 2025). 
